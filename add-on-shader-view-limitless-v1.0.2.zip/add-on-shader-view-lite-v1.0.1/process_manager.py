
import base64
import queue
import time
import traceback
import threading
import numpy as np
from concurrent.futures import ThreadPoolExecutor

from . import globals
from .utils import force_redraw, get_active_tree, get_tree_uid, get_node_uid

threads = []
result_executor = None


class Task:
    def __init__(self, func, *args, **kwargs):
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def execute(self):

        try:
            return self.func(*self.args, **self.kwargs)  # Run function
        except Exception as e:
            error_trace = traceback.format_exc()  # Get full error trace
            print(f"ERROR: Task {self.func.__name__} failed!\n{error_trace}")
            return None  # Ensure it doesn't crash
    
    def __call__(self):
        return self.execute()


def send_tasks():
    """
    Write a command to the command named pipe.
    """

    while globals.connection_as_client is None:
        time.sleep(0.1)

    try:
        while True:

            task_data = globals.task_queue.get()
              
            try:
                globals.connection_as_client.send(task_data)  # Send task to background process
            except BrokenPipeError:
                print("ERROR: Connection to background process lost!")
                break
            except Exception as e:
                error_details = traceback.format_exc()
                print(f"Error while sending task: {error_details}")
                continue

            # Check for stop signal
            if task_data.get("status", "").upper() == "STOP":
                print("Stopping send_tasks thread...")
                break
       
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error while sending task: {error_details}")
        
    finally:
        globals.connection_as_client.close()
        globals.connection_as_client = None
        

def read_results():


    while globals.connection_as_server is None:
        time.sleep(0.1)

    try:
        while True:
            
            data = {}

            if globals.connection_as_server.poll(timeout=0.05):
                try:
                    data = globals.connection_as_server.recv() 
                except EOFError:
                    print("ERROR: Connection closed by background process.")
                    break
                except Exception as e:
                    print(f"Error while reading data: {e}")
                    continue
            else:
                continue

            if not data:
                continue
            
            status = data.get("status", None)
        
            if status == "success": 
                result_executor.submit(Task(process_success_result, data))

            elif status == "READY":
                print("bg ready")
                globals.bg_ready.set()
                continue
            elif status == "STOP":
                break    
            elif status is not None:
                result_executor.submit(Task(handle_other_result, data))
            else:
                print(f"Warning: Result without status: {data}")

    except (ValueError, OSError, IOError):
        print("[read_results] stream closed, exiting read_results.")
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"ERROR: Other error during getting result: {error_details}")
    finally:
        globals.connection_as_server.close()  # Ensure the connection is closed
        globals.connection_as_server = None

        

def handle_other_result(result):
    """
    Handle rendering results based on their status.
    """
    try:
        status = result.get("status", "")
        node_id = result.get("node_id", None)
        tree_id = result.get("tree_id", None)

        node_tree = get_active_tree()
        if tree_id != get_tree_uid(node_tree):
            return

        if status == "error":
            print(f"Received error status for node {result['node_id']}, error: {result['error']}, script {result['script']}")
            
            for node in node_tree.nodes:
                if get_node_uid(node) == node_id:
                    if node.node_preview.show:
                        with globals.result_lock, globals.texture_lock, globals.error_lock:
                            # Remove only this node's result and cached texture
                            globals.result.pop(node_id, None)
                            globals.cashed_textures.pop(node_id, None)
                            globals.error_msg = "Rendering Error"
                        
                    break
        else:
            print(f"WARNING: Unhandled result status: {status}")
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in handle_result: {error_details}")
    
    finally:
        return None


def process_success_result(result):

    node_id = result.get("node_id", None)
    tree_id = result.get("tree_id", None)
    
    node_tree = get_active_tree()
    if tree_id != get_tree_uid(node_tree):
        return
    
    for node in node_tree.nodes:
        if get_node_uid(node) == node_id:
            if node.node_preview.show:
                update_result(result)
                force_redraw()

            break


def update_result(result):

    arr_b64 = result["encoded_numpy"]
    width = result["width"]
    height = result["height"]
    channels = result["channels"]
    dtype_str = result["dtype"]
    numpy_arr = decode_numpy_arr(arr_b64, dtype_str, height, width, channels)

    with globals.result_lock, globals.texture_lock, globals.error_lock:
        # Store the result per-node so multiple previews can coexist
        node_id = result["node_id"]
        globals.result[node_id] = {
            "node_id": node_id,
            "arr": numpy_arr,
            "timestamp": time.time()
        }

        # Clear only this node's cached texture
        globals.cashed_textures.pop(node_id, None)
        globals.error_msg = ""



def decode_numpy_arr(numpy_encoded, dtype_str, height, width, channels):
    preview_array = None

    if numpy_encoded is None:
        print(f"Don't get correct render result")
        preview_array = np.full((10, 10, 3), 0.7377889752388, dtype=np.float32)
    else:
        # decode and convert bytes to NumPy array
        raw_bytes = base64.b64decode(numpy_encoded)
        preview_array = np.frombuffer(raw_bytes, dtype=dtype_str).reshape((height, width, channels))
    
    return preview_array


def start():

    global threads, result_executor

    stop()
    if globals.task_queue is None:
        globals.task_queue = queue.SimpleQueue()
    
    read_results_thread = threading.Thread(target=read_results, args=(), daemon=True)
    send_tasks_thread = threading.Thread(target=send_tasks, args=(), daemon=True)
    result_executor = ThreadPoolExecutor(max_workers=1)
    
    read_results_thread.start()
    send_tasks_thread.start()

    threads.append(read_results_thread)
    threads.append(send_tasks_thread)

def register():
    start()


def stop():

    global threads, result_executor

    globals.task_queue = None

    for thread in threads:
        if thread is not None:
            thread.join(timeout=1.0)
            thread = None

    threads = []

    if result_executor:
        result_executor.shutdown(wait=False)
        result_executor = None
    

def unregister():
    stop()