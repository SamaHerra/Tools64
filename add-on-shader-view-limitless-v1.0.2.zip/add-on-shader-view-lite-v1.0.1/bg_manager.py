

import bpy
import os
import base64
import sys
import queue
import threading
import time
import traceback
import mathutils
import math
import numpy as np
from bpy_extras import image_utils
from contextlib import contextmanager
from multiprocessing.connection import Client, Listener


def process_path(filepath):
    """Process and normalize a file path for Blender and OS compatibility."""

    filepath = os.path.expanduser(filepath) # Expand user directory 
    filepath = bpy.path.abspath(filepath)  # Convert relative Blender paths to absolute
    filepath = os.path.normpath(filepath)  # Normalize OS-specific path separators
    filepath = filepath.replace("\\", "/")
    return filepath


@contextmanager
def redirect_stdout_to_file(to=os.devnull):

    fd = sys.stdout.fileno()

    def _redirect_stdout(to):
        sys.stdout.close() # + implicit flush()
        os.dup2(to.fileno(), fd) # fd writes to 'to' file
        sys.stdout = os.fdopen(fd, 'w') # Python writes to fd

    with os.fdopen(os.dup(fd), 'w') as old_stdout:
        with open(to, 'w') as file:
            _redirect_stdout(to=file)
        try:
            yield # allow code to be run with the redirected stdout
        finally:
            _redirect_stdout(to=old_stdout) # restore stdout.
                                            # buffering and flags such as
                                            # CLOEXEC may be different


def convert_image_to_result(filepath):
    """
    Load the image and return a numpy array.
    """

    image = image_utils.load_image(filepath, check_existing=True, force_reload=True)

    if image and len(image.pixels) == 0:
        image.reload()
        bpy.context.view_layer.update()
    
    if not image or len(image.pixels) == 0:
        print(f"Failed to load image from disk {filepath}.", file=sys.stderr, flush=True)
        return None
    
    channels = image.channels
    width, height = image.size
    arr = np.array(image.pixels[:], dtype=np.float32)
    
    return arr.reshape((height, width, channels))
    


def process_result(data):

    global result_queue

    try:
        arr = data['result']
        arr_bytes = arr.tobytes()

        # Base64 encode
        arr_b64 = base64.b64encode(arr_bytes).decode('ascii')
        channels = arr.shape[-1] if len(arr.shape) == 3 else 1

        extra_data = {
            "width": arr.shape[1],
            "height": arr.shape[0],
            "channels": channels,
            "dtype": str(arr.dtype),  # e.g. "float32"
        }

        data['encoded_numpy'] = arr_b64
        data.update(extra_data)

    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in process_array_result: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  # Pass the exception to sys.excepthook
        raise
    
    result_queue.put(data)



def update_env(context):
    # Force scene and dependency graph update
    context.window.view_layer = context.scene.view_layers[0]
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    depsgraph.update()



def execute_render_task(task_data):
    """
    Execute the rendering of a shader node in a separate thread.
    """
    global result_queue, temp_path

    import bpy

    if bpy.app.version >= (3, 0, 0):
        bpy.context.preferences.filepaths.file_preview_type = "NONE"

    def clean_up_scene():

        # Remove all images
        for image in bpy.data.images:
            bpy.data.images.remove(image, do_unlink=True)

        # Remove all materials
        for mat in bpy.data.materials:
            bpy.data.materials.remove(mat, do_unlink=True)

    script = task_data["script"]
    node_id = task_data["node_id"]
    tree_id = task_data["tree_id"]

    try:

        filepath = os.path.join(temp_path, f"{node_id}.png")
        filepath = process_path(filepath)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        scene = bpy.context.scene
        render_settings = scene.render
        render_settings.resolution_x = scene.render.resolution_y = 128
        render_settings.filepath = f'{filepath}'
        render_settings.image_settings.file_format = "PNG"
        render_settings.image_settings.color_mode = "RGBA"
        render_settings.image_settings.color_depth = "8"
        render_settings.image_settings.compression = 25

        bpy.context.view_layer.update()

        try:
            exec(script)
        except Exception as error:
            print(f"Script execution failed: {error}: {script}", file=sys.stderr, flush=True)
            return
        
        update_env(bpy.context)

        if not os.path.exists(scene.render.filepath):
            for _ in range(10):
                update_env(bpy.context)

        with redirect_stdout_to_file(os.devnull):
            bpy.ops.render.render(write_still=True, animation=False)
        
    except Exception as error:
        result_queue.put({"status": "error", "node_id": node_id, "tree_id": task_data.get("tree_id", ""),  "error": str(error), "script": script})
        clean_up_scene()
        return
    
    finally:
        
        result = convert_image_to_result(scene.render.filepath)
        if not(isinstance(result, np.ndarray) and result.size > 0):
            result_queue.put({"status": "error", "node_id": node_id, "tree_id": task_data.get("tree_id", ""),  "error": "render_error", "script": script})
            clean_up_scene()
            return

        data = {
            "status": "success", 
            "node_id": node_id,
            "tree_id": tree_id,
            "result": result,
            "index" : task_data.get("index", 0),
        }

        process_result(data)
        clean_up_scene()

        
def render_loop():
    """
    Continuously fetch and execute rendering tasks from the task queue.
    """
    global task_queue, result_queue, active_node

    try:
        while True:
            
            try:
                task_data = task_queue.get()
            except Exception as e:
                print(f"[render_loop] Error in reading task in render_loop: {e}", file=sys.stderr, flush=True)
                continue  # Avoid crashing the thread

            status = task_data.get("status", "")

            if status == "STOP":
                break
    
            elif status == "DRAW_PREVIEW":

                node_id = task_data["node_id"]
                if node_id != active_node:
                    continue

                execute_render_task(task_data)    
        
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in render_loop: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  # Pass the exception to sys.excepthook
        raise

        

def result_writer():
    """Send result data to the result pipe."""
    global result_queue, connection_as_client

    while connection_as_client is None:
        time.sleep(0.1)
    
    try:
        while True:
            data = result_queue.get()
            
            try:
                connection_as_client.send(data)
            except BrokenPipeError:
                print("Connection to main process lost!", file=sys.stderr, flush=True)
                os._exit(0)  # Hard exit
            except Exception as e:
                error_details = traceback.format_exc()
                print(f"Error while sending task: {error_details}", file=sys.stderr, flush=True)
                continue

            if data.get("status", "") == "STOP":
                break

    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in result_writer: {error_details}", file=sys.stderr, flush=True)

    finally:
        connection_as_client.close()  # Close connection when done
        connection_as_client = None



def task_reader():
    """
    Read tasks from the task named pipe and enqueue them for processing.
    """

    global result_queue, task_queue, connection_as_server, active_node
    
    while connection_as_server is None:
        time.sleep(0.1)

    try:
        while True:

            task_data = {}

            if connection_as_server.poll(timeout=0.05):
                try:
                    task_data = connection_as_server.recv()
                except EOFError:
                    print("Connection closed by main process (EOF). Exiting BG process.", file=sys.stderr, flush=True)
                    os._exit(0) # Hard exit
                except BrokenPipeError:
                    print("Broken pipe in task_reader. Exiting BG process.", file=sys.stderr, flush=True)
                    os._exit(0) # Hard exit
                except Exception as e:
                    print(f"Error while reading result: {e}", file=sys.stderr, flush=True)
                    continue
            else:
                continue

            if not task_data:
                continue

            status = task_data.get("status", "")

            if status == "DRAW_PREVIEW":

                active_node = task_data['node_id']
                task_queue.put(task_data)
                
            elif status == "STOP":
                task_queue.put({"status": "STOP"})
                result_queue.put({"status": "STOP"})
                print("STOP", file=sys.stderr, flush=True)
                break


    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in task_reader: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  # Pass the exception to sys.excepthook
        raise

    finally:
        connection_as_server.close()
        connection_as_server = None



def get_eevee_engine():
    available_engines = bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items.keys()
    for engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
        if engine in available_engines:
            return engine
    
    print("Add-on support only EEVEE engine!", file=sys.stderr, flush=True)
    sys.exit(1)


def make_setup_script(engine):
    return f"""

import bpy
from contextlib import suppress

scene = bpy.context.scene
scene.render.threads_mode = 'AUTO'
scene.render.use_compositing = False
scene.render.use_sequencer = False
scene.render.dither_intensity = 0.0
scene.render.use_overwrite = True
scene.render.use_persistent_data = False
scene.render.resolution_percentage = 100
scene.render.film_transparent = True
scene.render.engine = '{engine}'

scene.eevee.taa_samples = 2
scene.eevee.taa_render_samples = 2

with suppress(Exception):
    scene.eevee.use_shadows = False
    scene.eevee.use_bloom = False
    scene.eevee.use_gtao = False        
    scene.eevee.use_ssr = False         
    scene.eevee.use_motion_blur = False

"""



def start_background_server():
    """Start a BG server connection"""
    global connection_as_server, bg_port

    try:
        listener = Listener(("127.0.0.1", bg_port), authkey=b"secret")  # Secure with a key
        connection_as_server = listener.accept()  # Accept the connection
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error during start_background_server: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  
        sys.exit(1)


def wait_for_connection(main_port, timeout=5.0):
    """
    Wait for the main process to start and establish a connection.
    """
    global connection_as_client

    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            # Attempt to connect
            connection_as_client = Client(("127.0.0.1", main_port), authkey=b"secret")
            return  # Exit if successful
        
        except ConnectionRefusedError:
            time.sleep(0.3)  # Wait before retrying
        
        except Exception as e:
            error_details = traceback.format_exc()
            print(f"Unexpected error while connecting: {error_details}", file=sys.stderr, flush=True)
            sys.excepthook(*sys.exc_info())
            raise

    print(f"Failed to connect to main process on port {main_port} after {timeout} seconds.", file=sys.stderr, flush=True)
    sys.exit(1)



if __name__ == "__main__":

    if len(sys.argv) == 0:
        print('Bg process dont have args when start', file=sys.stderr, flush=True)
        sys.exit(1)

    separator_index = sys.argv.index("--") if "--" in sys.argv else len(sys.argv)
    main_port = int(sys.argv[separator_index + 1])
    bg_port = int(sys.argv[separator_index + 2])
    temp_path = sys.argv[separator_index + 3]
    os.makedirs(os.path.dirname(temp_path), exist_ok=True)


    active_node = None

    # Queues for task management
    result_queue = queue.SimpleQueue()
    task_queue = queue.SimpleQueue()

    connection_as_server = None
    threading.Thread(target=start_background_server, daemon=True).start()

    wait_for_connection(main_port)


    try:
        #run the rendering to init eevee environment
        script = make_setup_script(get_eevee_engine())
        
        exec(script)
        bpy.context.view_layer.update()
        with redirect_stdout_to_file(os.devnull):
            bpy.ops.render.render(write_still=False, animation=False)

    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in setup process: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  # Pass the exception to sys.excepthook
        raise

    result_thread = threading.Thread(target=result_writer, daemon=True)
    result_thread.start()

    # Start threads for task handling
    task_thread = threading.Thread(target=task_reader, daemon=True)
    task_thread.start()

    result_queue.put({"status": "READY"})

    try:
        render_loop()
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error in main process: {error_details}", file=sys.stderr, flush=True)
        sys.excepthook(*sys.exc_info())  # Pass the exception to sys.excepthook
        raise
    
    finally:

        # Signal all threads to stop and clean up resources
        task_queue.put({"status": "STOP"})
        result_queue.put({"status": "STOP"})

        task_thread.join()
        result_thread.join()

        result_queue = None
        task_queue = None

        sys.exit(0)