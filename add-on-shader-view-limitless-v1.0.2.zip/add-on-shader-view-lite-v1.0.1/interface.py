
import bpy
from bpy.types import Panel, Menu
from bpy.utils import register_class, unregister_class

from .utils import count_active_outputs, skip_node
from .operators import NODE_OT_OutputSocketSelectOperator, NODE_OT_ToggleHideOperator, NODE_OT_RerenderNodeOperator


class SPBaseMenu:
    @classmethod
    def poll(cls, context):
        space = context.space_data
        return (space.type == 'NODE_EDITOR'
                and space.node_tree is not None
                and space.node_tree.library is None)



class NODE_MT_SelectOutputSocketMenu(Menu, SPBaseMenu):
    bl_label = "SVL: Select Output Socket"
    bl_idname = "NODE_MT_output_socket_menu"
    
    def draw(self, context):
        layout = self.layout
        node = context.active_node

        if node is None:
            layout.label(text="No active node")
            return

        if not hasattr(node, 'outputs') or count_active_outputs(node) == 0:
            layout.label(text="No output sockets available")
            return
        
        current_output_index = node.node_preview.output_index
        
        if node.node_preview.output_index < 0:
            layout.label(text="No output sockets available")
            return

        is_script_node = node.type == 'SCRIPT' and isinstance(node, bpy.types.ShaderNodeScript)
        if is_script_node:
            layout.label(text="Add-on doesn't support Script Node")
            return


        col = layout.column(align=True)
        # Iterate over the node's output sockets and create a menu item for each one
        for i, socket in enumerate(node.outputs):

            is_unavailable = (socket.hide or not socket.enabled or socket.is_unavailable)
            is_selected = (i == current_output_index)
            row = col.row(align=True)

            if not is_unavailable:
                row.enabled = True
                op = row.operator(
                    NODE_OT_OutputSocketSelectOperator.bl_idname,
                    text=socket.name,
                    icon='RADIOBUT_ON' if is_selected else 'RADIOBUT_OFF'
                )
                op.index = i



def drawlayout(context, layout):

    selected_nodes = getattr(context, "selected_nodes", [])
    active_node = getattr(context, "active_node", None)

    is_single_node = bool(active_node and len(selected_nodes) == 1)
    is_script_node = bool(is_single_node and active_node.type == 'SCRIPT' and isinstance(active_node, bpy.types.ShaderNodeScript))

    # Start a single, aligned column
    col = layout.column(align=True)
    
    if not selected_nodes:
        col.label(text="No nodes selected in the Shader Editor")
        return

    if active_node and skip_node(active_node):
        col.label(text="ShaderViewLite not available for this node")
        return
    
    if active_node.type == 'SCRIPT' and isinstance(active_node, bpy.types.ShaderNodeScript):
        col.label(text="Script Node is not supported")
        return
    
    if active_node and count_active_outputs(active_node) == 0:
        col.label(text="No active outputs on active node")
        return

    # --- Toggle ON/OFF Node Preview ---
    sub = col.column(align=True)

    sub.enabled = is_single_node
    if not active_node.node_preview.show:
        sub.operator(NODE_OT_ToggleHideOperator.bl_idname, text="Show Preview", icon='HIDE_ON')
    else:
        sub.operator(NODE_OT_ToggleHideOperator.bl_idname, text="Hide Preview", icon='HIDE_OFF')
    sub.separator()

    # --- Output Sockets Menu ---
    sub = col.column(align=True)
    sub.enabled = not is_script_node
    sub.menu(NODE_MT_SelectOutputSocketMenu.bl_idname, text="Select Output Socket", icon='LAYER_USED')
    sub.separator()

    col.operator(NODE_OT_RerenderNodeOperator.bl_idname, text="Re-render Node", icon='FILE_REFRESH')



class NODE_MT_ShaderViewMenu(Menu, SPBaseMenu):
    bl_idname = "NODE_MT_main_preview_menu"
    bl_label = "ShaderViewLite Menu"

    def draw(self, context):
        self.layout.operator_context = 'INVOKE_DEFAULT'
        drawlayout(context, self.layout)

class NODE_PT_ShaderViewPanel(Panel, SPBaseMenu):
    bl_idname = "NODE_PT_main_panel_menu"
    bl_space_type = 'NODE_EDITOR'
    bl_label = "Shader View Lite"
    bl_region_type = "UI"
    bl_category = "Shader View Lite"

    def draw(self, context):
        self.layout.label(text="(Quick access: Shift+P)")
        drawlayout(context, self.layout)

addon_keymaps = []


classes = (
    NODE_MT_SelectOutputSocketMenu,
    NODE_MT_ShaderViewMenu,
    NODE_PT_ShaderViewPanel,
)


def register():

    for cls in classes:
        register_class(cls)

    wm = bpy.context.window_manager
    keymap = wm.keyconfigs.addon.keymaps.new(name="Node Editor", space_type="NODE_EDITOR")
    
    # Keymap for ShaderViewMenu (Shift + P)
    keymap_item = keymap.keymap_items.new('wm.call_menu', "P", "PRESS", shift=True)
    keymap_item.properties.name = "NODE_MT_main_preview_menu"  
    addon_keymaps.append((keymap, keymap_item))
    
    # Keymap for SelectOutputSocketMenu (CTRL + O)
    keymap_item = keymap.keymap_items.new('wm.call_menu', "O", "PRESS", ctrl=True)
    keymap_item.properties.name = "NODE_MT_output_socket_menu"  
    addon_keymaps.append((keymap, keymap_item))

    # Keymap for ToggleHideOperator (CTRL + E)
    keymap_item = keymap.keymap_items.new(NODE_OT_ToggleHideOperator.bl_idname, "E", "PRESS", ctrl=True)
    addon_keymaps.append((keymap, keymap_item))

     # Keymap for ToggleHideOperator (CTRL + R)
    keymap_item = keymap.keymap_items.new(NODE_OT_RerenderNodeOperator.bl_idname,  "R", "PRESS", ctrl=True)
    addon_keymaps.append((keymap, keymap_item))



def unregister():

    for cls in classes:
        unregister_class(cls)
    
    for keymap, keymap_item in addon_keymaps:
        keymap.keymap_items.remove(keymap_item)

    addon_keymaps.clear()