

bl_info = {
    "name": "Shader View Lite V2",
    "author": "SamaHerra",
    "version": (1, 0, 2),
    "blender": (3, 0, 0),
    "category": "Node",
    "location": "Shader Node Editor",
    "description": "View real-time thumbnail above selected Shader Node for instant outputs preview",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

from . import interface
from . import preferences
from . import operators
from . import setup
from . import process_manager
from . import display_manager
from . import update_manager


def register():

    
    preferences.register() # register add-on and classes
    process_manager.register() # start reading/ write thread
    setup.register() #start BG 
    update_manager.register() # start checking updates
    display_manager.register() # start draw/render preview    
    interface.register()
    operators.register()
    

def unregister():


    interface.unregister()
    operators.unregister()
    display_manager.unregister() # stop draw/render preview
    update_manager.unregister() # stop check updates
    setup.unregister() #stop BG
    process_manager.unregister() # stop reading/ write thread
    preferences.unregister() # unregister add-on and classes

