
import tempfile
import bpy
import gpu
import time
import socket
import numpy as np
import sys
import traceback
import subprocess
import threading
import os
from pathlib import Path
from multiprocessing.connection import Client, Listener

from . import globals


threads = []

def setup_default_textures():
    
    DEFAULT_SIZE = 16

    empty_numpy = np.full((DEFAULT_SIZE, DEFAULT_SIZE, 3), (0.5, 0.5, 0.5), dtype=np.float32)
    empty_numpy_buffer = gpu.types.Buffer("FLOAT", DEFAULT_SIZE * DEFAULT_SIZE * 3, empty_numpy.flatten())
    globals.empty_texture = gpu.types.GPUTexture((DEFAULT_SIZE, DEFAULT_SIZE), format="RGB16F", data=empty_numpy_buffer)

    error_numpy = np.full((DEFAULT_SIZE, DEFAULT_SIZE, 3), (0.8, 0.25, 0.25), dtype=np.float32)
    error_numpy_buffer = gpu.types.Buffer("FLOAT", DEFAULT_SIZE * DEFAULT_SIZE * 3, error_numpy.flatten())
    globals.error_texture = gpu.types.GPUTexture((DEFAULT_SIZE, DEFAULT_SIZE), format="RGB16F", data=error_numpy_buffer)

    return None


def get_bg_blend_filepath():
    """
    """
    script_path = os.path.dirname(os.path.realpath(__file__))
    subpath = "data" + os.sep + "preview.blend"
    return os.path.join(script_path, subpath)


def get_process_flags():
    """
    """
    flags = 0x00004000 # CREATE_NO_WINDOW
    if sys.platform != "win32": 
        flags = 0
    return flags


def get_bg_args(script_name, bg_blend_filepath, ports):
    """
    Prepare arguments to launch Blender in background with debug options.
    """

    # Build the path to the script
    addon_dir = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(addon_dir, script_name)
    main_port, bg_port = ports

    # Arguments for running Blender in background with debug
    args = [
        bpy.app.binary_path,           # Blender binary
        "--background",                # Run in background
        "--factory-startup",           # Use factory settings (no user prefs)
        "--addons", "io_import_images_as_planes",
        "-noaudio",                    # Disable audio
        bg_blend_filepath,             # Path to .blend file
        "--python", script_path,       # Script to execute
        "--",                          # Separator for script arguments
        str(main_port),                # Pass main process port as a string
        str(bg_port),                  # Pass background process port as a string
        globals.PATH
    ]
    
    return args


def start_bg_process(script_name, ports):
    """
    Starts Blender as a background process with the given script.
    """
    try:
        # Generate arguments for Blender
        args = get_bg_args(script_name, get_bg_blend_filepath(), ports)

        # Prepare environment variables
        blender_user_scripts_dir = Path(__file__).resolve().parents[2]
        env = os.environ.copy()  # Copy current environment
        env["BLENDER_USER_SCRIPTS"] = str(blender_user_scripts_dir)

        process = subprocess.Popen(
            args,
            stdin=subprocess.DEVNULL, 
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            creationflags=get_process_flags(),
            env=env,
            text=True,
            bufsize=1
        )

        return process
    
    except FileNotFoundError as file_error:
        print(f"ERROR: Blender executable not found or script missing: {file_error}")
    
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"ERROR: Unexpected error starting Blender process {error_details}")



def stop_bg_process():
    """
    Signals the background task manager to stop all threads.
    """
    try:
        json_args = {
                "status": "STOP"
            }
        globals.task_queue.put(json_args)
    
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"ERROR: Unexpected error in stop_bg: {error_details}")



def stop():

    if globals.background_process is not None: 
        stop_bg_process() #send Stop signal to bg and stop related threads
    
    global threads
    for thread in threads:
        if thread is not None:
            thread.join(timeout=1.0)
            thread = None

    threads = []

    if globals.background_process is not None:   
        try:
            globals.background_process.communicate(timeout=2.0)
        except subprocess.TimeoutExpired:
            globals.background_process.kill()
            globals.background_process.communicate()
            print("Background Process was killed after timeout.")
        finally:
            globals.bg_ready.clear()
            globals.background_process = None


def stream_reader(pipe):
    """
    Read lines from a pipe and log them using the provided logging function.
    """
    try:
        for line in iter(pipe.readline, b""):

            decoded_line = line.strip()

            if not decoded_line:
                continue  

            if decoded_line == "STOP":  # Detect stop message
                break 

            print(decoded_line)

    except (ValueError, OSError, IOError):
        print("Stream reader stopped: Pipe was closed.")
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error reading stream: {error_details}")


def start_main_server(port):
    """Start a Main server connection"""
    try:
        listener = Listener(("127.0.0.1", port), authkey=b"secret")
        globals.connection_as_server = listener.accept()
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Error during start main_server: {error_details}")
        return


def wait_for_bg_connection(bg_port, timeout=5.0):
    """
    Wait for the background process to start and establish a connection.
    """
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            # Attempt to connect
            globals.connection_as_client = Client(("127.0.0.1", bg_port), authkey=b"secret")
            return  # Exit if successful
        
        except ConnectionRefusedError:
            time.sleep(0.3)  # Wait before retrying
        
        except Exception as e:
            error_details = traceback.format_exc()
            print(f"Unexpected error while connecting: {error_details}")
            return
            
    print(f"Failed to connect to background process on port {bg_port} after {timeout} seconds.") 


def find_free_ports():
    """
    Find two unoccupied ports on localhost that do not conflict.
    """
    ports = []
    
    while len(ports) < 2:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", 0))  # Bind to any free port
            s.listen(1)  # Start listening to prevent immediate reuse issues
            free_port = s.getsockname()[1]  # Retrieve assigned port

            # Ensure it's not the excluded port
            if free_port not in ports:
                ports.append(free_port)

    return tuple(ports)



def start():

    global threads

    main_port, bg_port = find_free_ports()

    globals.background_process = start_bg_process("bg_manager.py", (main_port, bg_port))

    stderr_thread = threading.Thread(target=stream_reader, args=(globals.background_process.stderr, ), daemon=True)
    stderr_thread.start()
    threads.append(stderr_thread)

    # Start the main process server for receiving results
    start_main = threading.Thread(target=start_main_server, args=(main_port, ), daemon=True)
    start_main.start()
    threads.append(start_main)

    # Connect to background process
    connect_to_bg = threading.Thread(target=wait_for_bg_connection, args=(bg_port, ), daemon=True)
    connect_to_bg.start()
    threads.append(connect_to_bg)


def register():

    bpy.app.timers.register(setup_default_textures)

    globals.connection_as_server = None
    globals.connection_as_client = None

    globals.PATH = tempfile.mkdtemp()

    if not globals.PATH or not os.path.isdir(globals.PATH):
        raise ValueError("PATH must be set to a valid directory path")
    
    if not os.access(globals.PATH, os.W_OK):
        raise PermissionError(f"Write permission denied for directory: {globals.PATH}")

    start()


def unregister():

    stop()
    
    globals.connection_as_server = None
    globals.connection_as_client = None

    globals.error_texture = None
    globals.empty_texture = None

    globals.PATH = ""
