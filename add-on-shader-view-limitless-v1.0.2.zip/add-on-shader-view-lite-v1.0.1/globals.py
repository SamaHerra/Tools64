
import queue
import threading
from typing import Optional

bg_ready = threading.Event()
tree_ready = threading.Event()

object_material = ""

# Single legacy cache removed; use per-node cache mapping `cashed_textures`
texture_lock = threading.Lock()

result = {}
result_lock = threading.Lock()

error_msg = ""
error_lock = threading.Lock()

task_queue: Optional[queue.SimpleQueue] = None

tree_layout = {}
tree_lock = threading.Lock()

error_texture = None
empty_texture = None

# Per-node cached gpu textures: { node_id: GPUTexture }
cashed_textures = {}

shader = None

background_process = None

connection_as_server = None
connection_as_client = None

PATH = ""