
import os
import bpy
import mathutils

from . import globals
from .utils import find_socket_index, get_identifier, get_tree_links_in, process_path, skip_attr, skip_node_reroute


def get_tree_uid(node_tree):
    return get_identifier(node_tree.name_full) 

def get_node_uid(node):

    try:
        node_str = get_tree_uid(node.id_data) + "_" + get_identifier(node.name)
        
    except Exception:
        print(f"ERROR: [{node}] Node has been removed from memory.")
        return None

    return node_str


def attribute_to_string(value):
    """Convert a node attribute value to a string suitable for script."""

    if isinstance(value, (mathutils.Color, mathutils.Vector, bpy.types.bpy_prop_array)):
        # Convert fixed-size arrays, vectors, and colors to a list representation
        return str(list(value))
    elif isinstance(value, (float, int)):
        # Convert numeric values directly to string
        return str(round(value, 6) if isinstance(value, float) else value)
    elif isinstance(value, str):
        # Use repr to handle string quotes properly
        return repr(value)
    elif isinstance(value, mathutils.Euler):
        # Represent Euler with its order
        return f"mathutils.Euler({[round(v, 6) for v in value]}, '{value.order}')"
    elif isinstance(value, bool):
        # Convert boolean to string representation
        return "True" if value else "False"
    elif isinstance(value, mathutils.Matrix):
        # Handle Matrix type explicitly
        matrix_str = ", ".join(str([round(v, 6) for v in row]) for row in value)
        return f"mathutils.Matrix([{matrix_str}])"
    elif isinstance(value, mathutils.Quaternion):
        # Handle Quaternion type explicitly
        return f"mathutils.Quaternion({[round(v, 6) for v in value]})"
    elif isinstance(value, list):
        # Handle plain Python lists
        return str([round(v, 6) if isinstance(v, float) else v for v in value])
    elif isinstance(value, tuple):
        # Handle tuples
        return str(tuple(round(v, 6) if isinstance(v, float) else v for v in value))
    else:
        # If type is unsupported, return None
        return None


def get_attributes(node):
    """Get a list of non-callable, non-special, and writable attributes from node."""
    attributes = []

    for attr in dir(node):
        # Exclude methods, “dunder” methods, internal Blender props like bl_*,
        # or anything your custom skip_attr(attr) says to skip
        if skip_attr(attr):
            continue
        if callable(getattr(node, attr, None)):
            continue
        if attr.startswith("__") or attr.startswith("bl_"):
            continue
        
        # Now attempt a safe "get" of that attribute:
        try:
            dummy = getattr(node, attr)
            # If reading succeeded, we consider it a valid “readable” property.
            attributes.append(attr)

        except (AttributeError, TypeError):
            # Some props are read-protected or raise TypeError if reading not allowed
            pass
        except Exception as ex:
            print(f"Skipping attribute '{attr}' due to error: {ex}", level="WARNING")
            pass

    return attributes


def attributes_to_script(attributes, node, script, node_id):
    """
    Convert node attributes to script code and hash.
    """
    
    if node_id is None:
        node_id = get_node_uid(node)
    
    for attribute in attributes:
        value = attribute_to_string(getattr(node, attribute))
        if value is not None:
            script.append(f"with suppress(Exception): {node_id}.{attribute} = {value}")


def is_script_node(node): 
    return node.type == 'SCRIPT' and isinstance(node, bpy.types.ShaderNodeScript)


def extract_node_image_path(node):
    """
    Extract or retrieve the file path of an image from a node.
    """

    image = getattr(node, "image", None)
    if not image:
        print("ERROR: No image found on node.", level="ERROR")
        return None

    is_packed = bool(image.packed_files)

    def save_packed_image(image, packed_path):
        """Save 'img' to a unique temporary path and return that path."""
        # If 'name_hint' is empty, fallback to image.name

        image_name = os.path.splitext(bpy.path.basename(packed_path.replace("\\", "/")))[0]
        
        for img in bpy.data.images:
            if img.name == image_name and img.filepath and img.filepath == packed_path:
                return packed_path

        # If the user had an original path with an extension, keep it:
        image_ext = os.path.splitext(packed_path)[-1].lower() or ".png"
        temp_filename = f"packed_{image_name}{image_ext}"
        temp_path = os.path.join(globals.PATH, temp_filename)

        if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
            print(f"Reusing existing file: {temp_path}")
            return temp_path

        try:
            image.save_render(temp_path)
        except Exception as ex:
            print(f"ERROR: Could not save packed image '{image.name}': {ex}", level="ERROR")
            return None

        return temp_path

    if not is_packed:
        raw_path = bpy.path.abspath(image.filepath)
        if not os.path.exists(raw_path):
            print(f"ERROR: Image file does not exist: {raw_path}", level="ERROR")
            return None
        return raw_path

    filepath = image.packed_files[0].filepath or image.filepath
    return save_packed_image(image, filepath)


def node_attributes_to_script(node, script):
    """Add lines to the script to set attributes of a node."""
    node_id = get_node_uid(node)

    attributes_to_script(get_attributes(node), node, script, f"{node_id}")

    if node.type == 'VALTORGB':  # ColorRamp node
        color_ramp = node.color_ramp
        attributes_to_script(get_attributes(color_ramp), color_ramp, script, f"{node_id}.color_ramp")

        script.append(f"{node_id}.color_ramp.elements.remove({node_id}.color_ramp.elements[0])")
        for i in range(len(color_ramp.elements) - 1):
            script.append(f"{node_id}.color_ramp.elements.new(0)")
        
        for i, element in enumerate(color_ramp.elements):
            position = element.position
            color = element.color
            color_str = ', '.join(map(str, color[:]))
            script.append(f"{node_id}.color_ramp.elements[{i}].position = {position}")
            script.append(f"{node_id}.color_ramp.elements[{i}].color = ({color_str})")

    if node.type in {'CURVE_RGB', 'CURVE_FLOAT', 'CURVE_VEC'}:
        mapping = node.mapping

        attributes_to_script(get_attributes(mapping), mapping, script, f"{node_id}.mapping")

        for curve_index, curve in enumerate(mapping.curves):
            
            required_points = max(0, len(curve.points) - 2)

            # Add the required number of points
            for i in range(required_points):
                script.append(f"{node_id}.mapping.curves[{curve_index}].points.new(0, 0)")

            for point_index, point in enumerate(curve.points):
                location_str = attribute_to_string(point.location) 
                handle_type_str = attribute_to_string(point.handle_type)
    
                script.append(f"{node_id}.mapping.curves[{curve_index}].points[{point_index}].location = {location_str}")
                script.append(f"{node_id}.mapping.curves[{curve_index}].points[{point_index}].handle_type = {handle_type_str}")
                
        script.append(f"{node_id}.mapping.update()")

    if node.type == 'TEX_IMAGE':  
        image = node.image
        if image:

            image_source = image.source

            if image_source == "TILED":
                script.append("# ERROR_MSG ERROR_IMG_SOURCE")
                return
            
            if image_source == "GENERATED":
                script.append("# ERROR_MSG ERROR_IMG_SOURCE")
                return

            if image_source in {"SEQUENCE", "MOVIE"}:
                script.append("# ERROR_MSG ERROR_IMG_SOURCE")
                return

            try:
                image_path = extract_node_image_path(node)
            except Exception as e:
                script.append("# ERROR_MSG ERROR_IMG")
                print(f"Error in extract image path {image}: {e}", level="ERROR")
                return
            
            if image_path is None:
                script.append("# ERROR_MSG ERROR_IMG")
                return

            image_path_resolved = process_path(image_path)

            if os.path.exists(image_path_resolved): #if the file exists
                script.append("try:")
                script.append(f"    {node_id}.image = bpy.data.images.load('{image_path_resolved}', check_existing=True)")
                script.append("except Exception as e:")
                script.append(f"    print(f'[{node_id}] Error loading image for node {node.name}: {{e}}', file=sys.stderr, flush=True)")
                
            else:
                print(f"[{node_id}] image load has error")
                script.append("# ERROR_MSG ERROR_IMG")
                script.append(f"{node_id}.image = None")
        else:
            print(f"[{node_id}] Image node has no image assigned.")
            script.append("# ERROR_MSG ERROR_IMG")
            script.append(f"{node_id}.image = None")

    if node.bl_idname == 'ShaderNodeAttribute':
        script.append("# ERROR_MSG ERROR_NODE")

    if is_script_node(node):
        script.append("# ERROR_MSG ERROR_SCRIPT")
                    


def node_links_to_script(node, links_script):
    """
    Generate script code for links connected to a node's inputs.
    """
    node_tree = node.id_data
    node_tree_id = get_tree_uid(node_tree)

    in_links = get_tree_links_in(node_tree)
    node_id = get_node_uid(node)

    for i, input_socket in enumerate(node.inputs):
        if input_socket in in_links:
            
            if input_socket.is_unavailable or not input_socket.enabled:
                continue

            link = in_links[input_socket]

            if not link.from_node:
                print(f"Invalid link for input socket {input_socket} in node {node}.", level="Warning")
                continue

            from_node, from_socket = skip_node_reroute(link.from_node, link.from_socket)

            if from_node and from_socket:

                if is_script_node(from_node):
                    links_script.append("# ERROR_MSG ERROR_SCRIPT")
                    continue

                from_node_id = get_node_uid(from_node)

                output_index = find_socket_index(from_node.outputs, from_socket)
                input_index = find_socket_index(node.inputs, input_socket)

                if output_index is None or input_index is None:
                    print(f"Skipping invalid link between nodes {node} and {from_node}, sockets {input_socket} and {link.from_socket}.")
                    continue

                links_script.append(
                    f"{node_tree_id}.links.new({from_node_id}.outputs[{output_index}], {node_id}.inputs[{input_index}])"
                )


def io_node_sockets_to_script(node, node_script):
    """
    Generate script code and hash for a node's input and output sockets.
    """

    node_id = get_node_uid(node)

    if is_script_node(node):
        node_script.append("# ERROR_MSG ERROR_SCRIPT")
        return

    # Process input sockets
    for i, input_socket in enumerate(node.inputs):
        if input_socket.is_unavailable or not input_socket.enabled:
            continue

        if not input_socket.is_linked and hasattr(input_socket, "default_value"):
            value = attribute_to_string(input_socket.default_value)

            if value is not None:
                node_script.append(f"{node_id}.inputs[{i}].default_value = {value}")


    # Process output sockets
    for i, output_socket in enumerate(node.outputs):
        if output_socket.is_unavailable or not output_socket.enabled:
            continue

        if hasattr(output_socket, "default_value"):
            value = attribute_to_string(output_socket.default_value)
            
            if value is not None:
                node_script.append(f"{node_id}.outputs[{i}].default_value = {value}")

    

def get_node_script_and_hash(node):
    """
    Generate script text for the node, compute a combined hash
    """
    node_script, links_script = [], []

    node_tree = node.id_data
    node_tree_id = get_tree_uid(node_tree)

    # Get node identifier
    node_id = get_node_uid(node)

    # Generate script text for node creation
    node_script.append(f"{node_id} = {node_tree_id}.nodes.new(type='{node.bl_idname}')")
    node_script.append(f"{node_id}.name = {repr(node.name)}")

    # Collect attributes and their values
    node_attributes_to_script(node, node_script)

    # Collect i/o sockets default value
    io_node_sockets_to_script(node, node_script)

    # Collect incoming links
    node_links_to_script(node, links_script)

    return node_script, links_script


def group_sockets_to_script(node_group, script):
    """
    Generate script code and hash for the sockets of a node group.
    """

    group_tree_id = get_tree_uid(node_group.node_tree)

    if bpy.app.version >= (4, 0, 0):
        for i, socket_item in enumerate(node_group.node_tree.interface.items_tree):

            if socket_item.item_type == "SOCKET":

                script.append(f"socket_{group_tree_id}_{i} = {group_tree_id}.interface.new_socket({repr(socket_item.name)}, "
                              f"in_out={repr(socket_item.in_out)}, "
                              f"socket_type={repr(socket_item.bl_socket_idname)})")
                
                if hasattr(socket_item, "default_value"):
                    value = attribute_to_string(socket_item.default_value)
                    if value is not None:
                        script.append(f"socket_{group_tree_id}_{i}.default_value = {value}")
                        
    else:
        for socket_interface in node_group.inputs:
            script.append(f"{group_tree_id}.inputs.new({repr(socket_interface.bl_socket_idname)}, {repr(socket_interface.name)})")
                
        for socket_interface in node_group.outputs:
            script.append(f"{group_tree_id}.outputs.new({repr(socket_interface.bl_socket_idname)}, {repr(socket_interface.name)})")
            

def get_group_node_script_and_hash(node_group):
    """
    Generate script code for the node, compute a combined hash
    """
    node_script, links_script = [], []

    # Get node identifier
    node_group_id = get_node_uid(node_group)
    group_tree_id = get_tree_uid(node_group.node_tree)

    parent_tree = node_group.id_data
    parent_tree_id = get_tree_uid(parent_tree)

    # Fetch all input and output nodes
    input_nodes = [node for node in node_group.node_tree.nodes if isinstance(node, bpy.types.NodeGroupInput)]
    output_nodes = [node for node in node_group.node_tree.nodes if isinstance(node, bpy.types.NodeGroupOutput)]

    # Generate script text for group node creation
    node_script.append(f"{group_tree_id} = bpy.data.node_groups.new('{node_group.name}', 'ShaderNodeTree')")
    node_script.append(f"{node_group_id} = {parent_tree_id}.nodes.new('ShaderNodeGroup')")
    node_script.append(f"{node_group_id}.node_tree = {group_tree_id}")
    
    for input_node in input_nodes:
        input_node_id = get_node_uid(input_node)
        node_script.append(f"{input_node_id} = {group_tree_id}.nodes.new('NodeGroupInput')")
        attributes_to_script(get_attributes(input_node), input_node, node_script, f"{input_node_id}")

    for output_node in output_nodes:
        output_node_id = get_node_uid(output_node)
        node_script.append(f"{output_node_id} = {group_tree_id}.nodes.new('NodeGroupOutput')")
        attributes_to_script(get_attributes(output_node), output_node, node_script, f"{output_node_id}")


    group_sockets_to_script(node_group, [])
    io_node_sockets_to_script(node_group, [])
    node_links_to_script(node_group, [])

    return node_script, links_script


def get_node_script(node):
    """
    Update the script, links, and hash for a given node.
    """

    node_script, links_script = [], []

    if isinstance(node, bpy.types.ShaderNodeGroup):
        node_script, links_script = get_group_node_script_and_hash(node)
    else:
        node_script, links_script = get_node_script_and_hash(node)

    return node_script, links_script
