
import time
from bpy.types import Operator
from bpy.props import IntProperty
from bpy.utils import register_class, unregister_class
from .update_manager import render_node
from .utils import force_redraw, get_node_uid, find_first_available_output, apply_output_index, get_addon_prefs
from . import globals

def check(cls, context):
    space = context.space_data
    if space is None:
        cls.poll_message_set("No space data was found in the current node editor.")
        return False
    if not hasattr(space, "node_tree") or space.node_tree is None:
        cls.poll_message_set("No node tree was found in the current node editor.")
        return False
    if space.type != 'NODE_EDITOR' and space.tree_type != 'ShaderNodeTree':
        cls.poll_message_set("Current editor is not a Shader Editor.")
        return False
    if space.node_tree.library is not None:
        cls.poll_message_set("Current node tree is linked from another .blend file.")
        return False
    return True

def check_active(cls, context):
    if context.active_node is None or not context.active_node.select:
        cls.poll_message_set("No active node selected.")
        return None
    return True

def check_selected(cls, context, max=float('inf')):
    num_selected = len(context.selected_nodes)
    if num_selected > max:
        cls.poll_message_set(f"{num_selected} nodes are selected, but this operator can only work on {max}")
        return False
    if num_selected == 0:
        cls.poll_message_set("At least 1 nodes must be selected.")
        return False
    return True


class NODE_OT_OutputSocketSelectOperator(Operator):
    bl_idname = "node.select_output_socket"
    bl_label = "Select Output Socket"
    bl_description = "Select the output socket for the node preview"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(
        name="Output Index",
        description="Index of selected output socket",
    )


    @classmethod
    def poll(cls, context):
        # Allow toggling for one or multiple selected nodes
        return (check(cls, context)
            and check_selected(cls, context))
    
    def execute(self, context):
        node = context.active_node
        node.node_preview.output_index = self.index

        with globals.result_lock, globals.error_lock, globals.texture_lock:
            node_id = get_node_uid(node)
            globals.result[node_id] = {
                "node_id": node_id,
                "arr": None,
                "timestamp": time.time()
            }
            globals.cashed_textures.pop(node_id, None)
            globals.error_msg = ""

        render_node(node)
        force_redraw()

        return {'FINISHED'}


class NODE_OT_ToggleHideOperator(Operator):
    bl_idname = "node.toggle_hide"
    bl_label = "SVL: Toggle Node Preview"
    bl_description = "Hide or show all node previews"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return (check(cls, context)
                and check_selected(cls, context, 1)
                and check_active(cls, context))

    def execute(self, context):
        selected = list(getattr(context, 'selected_nodes', []) or [])
        if not selected:
            return {'CANCELLED'}

        for node in selected:
            try:
                node.node_preview.show = not node.node_preview.show
            except Exception:
                continue

            node_id = get_node_uid(node)
            if node.node_preview.show:
                # Ensure a valid output index is set so the preview is renderable
                if node.node_preview.output_index < 0:
                    out_idx = find_first_available_output(node)
                    if out_idx is not None:
                        apply_output_index(node, out_idx)

                # Enable preview: create per-node pending result and render
                with globals.result_lock, globals.error_lock, globals.texture_lock:
                    globals.result[node_id] = {
                        "node_id": node_id,
                        "arr": None,
                        "timestamp": time.time()
                    }
                    globals.cashed_textures.pop(node_id, None)
                    globals.error_msg = ""

                render_node(node)
            else:
                # Disable preview: remove per-node result and cached texture
                with globals.result_lock, globals.texture_lock, globals.error_lock:
                    globals.result.pop(node_id, None)
                    globals.cashed_textures.pop(node_id, None)

        force_redraw()

        return {'FINISHED'}



class NODE_OT_RerenderNodeOperator(Operator):
    bl_idname = "node.rerender_preview"
    bl_label = "SVL: Rerender Preview"
    bl_description = "Re-render the preview thumbnail"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return (check(cls, context)
                and check_selected(cls, context, 1)
                and check_active(cls, context))

    def execute(self, context):
        active_node = context.active_node
        if active_node.node_preview.show:
            with globals.result_lock, globals.error_lock:
                node_id = get_node_uid(active_node)
                globals.result[node_id] = {
                    "node_id": node_id,
                    "arr": None,
                    "timestamp": time.time()
                }
                globals.error_msg = ""

            render_node(active_node)

        return {'FINISHED'}


classes = (
    NODE_OT_OutputSocketSelectOperator,
    NODE_OT_ToggleHideOperator,
    NODE_OT_RerenderNodeOperator
)


class NODE_OT_PreviewOptionsOperator(Operator):
    bl_idname = "node.svl_preview_options"
    bl_label = "ShaderView Options"
    bl_description = "Open ShaderView options for selected node(s)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return (check(cls, context) and check_selected(cls, context))

    def draw(self, context):
        layout = self.layout
        selected = list(getattr(context, 'selected_nodes', []) or [])
        col = layout.column(align=True)
        col.label(text=f"Selected: {len(selected)} node(s)")
        col.separator()
        col.operator(NODE_OT_ToggleHideOperator.bl_idname, text="Toggle Selected Previews")
        col.operator(NODE_OT_RerenderNodeOperator.bl_idname, text="Re-render Active Preview")
        col.separator()
        prefs = None
        try:
            prefs = get_addon_prefs(context)
        except Exception:
            prefs = None

        if prefs is not None:
            row = col.row(align=True)
            row.prop(prefs, 'live_update_enabled', text='Live Update')
            row = col.row(align=True)
            row.prop(prefs, 'live_update_interval', text='Interval (s)')

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=260)

    def execute(self, context):
        # Popup buttons call sub-operators; nothing to do here.
        return {'FINISHED'}


# Add the popup operator to registration list
classes = classes + (NODE_OT_PreviewOptionsOperator,)

def register():

    for cls in classes:
        register_class(cls)

def unregister():

    for cls in classes:
        unregister_class(cls)

    