
import bpy
from bpy.app.handlers import persistent


from . import globals
from .utils import (
    count_active_outputs, check_node, 
    get_node_uid, get_space, get_context_region, get_zoom, 
    skip_node, get_active_tree
)
from .display_preview import draw_empty, draw_preview, draw_setup

draw_handler = None

def draw_node(node, view2d, zoom):

    with globals.error_lock:
        if globals.error_msg:
            draw_empty(node, globals.error_texture, globals.error_msg, view2d, zoom)
            return
    node_id = get_node_uid(node)

    # If we don't have a result for this node yet, show rendering placeholder
    with globals.result_lock:
        node_result = globals.result.get(node_id)

    if not node_result or node_result.get('arr') is None:
        draw_empty(node, globals.empty_texture, "rendering...", view2d, zoom)
        return

    # Draw preview using the per-node result
    draw_preview(node, view2d, zoom)
    



@persistent
def draw_callback():
    """
    Draw callback function that iterates over all shader nodes in the node tree,
    checks if they have an image path and are enabled, then draws the preview.
    """

    if globals.bg_ready.is_set():

        if not globals.tree_ready.is_set():
            return
        
        if not (bpy.context.active_object and bpy.context.active_object.active_material):
            return

        space = get_space()
        if not space:
            return
            
        node_tree = get_active_tree()
        if not node_tree:
            return

        region = get_context_region()
        if not region:
            return
        
        # Cache view2d and UI parameters
        view2d = region.view2d
        if not view2d:
            return
        
        zoom = get_zoom(region)
        
        def can_draw(node):
            return (
                not skip_node(node)
                and check_node(node)
                and node.node_preview.show
                and count_active_outputs(node)
                and node.node_preview.output_index != -1
            )

        # Draw active node first (if visible) then other visible nodes
        active_node = getattr(bpy.context, 'active_node', None)
        if active_node and can_draw(active_node):
            draw_node(active_node, view2d, zoom)

        for node in node_tree.nodes:
            if node is active_node:
                continue
            if can_draw(node):
                draw_node(node, view2d, zoom)
    
    else:
        draw_setup("Initializing background rendering process...")


def register():

    global draw_handler

    if draw_handler is None:
        draw_handler = bpy.types.SpaceNodeEditor.draw_handler_add(draw_callback, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    
    global draw_handler

    if draw_handler is not None:
        bpy.types.SpaceNodeEditor.draw_handler_remove(draw_handler, 'WINDOW')
        draw_handler = None