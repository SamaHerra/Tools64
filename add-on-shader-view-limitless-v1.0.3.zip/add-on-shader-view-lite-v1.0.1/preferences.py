
import bpy
from bpy.types import AddonPreferences, PropertyGroup
from bpy.utils import register_class, unregister_class
from bpy.props import IntProperty, BoolProperty, StringProperty, FloatProperty
from .utils import  get_addon_name


class ShaderViewAddonPreferences(AddonPreferences):
    
    bl_idname = get_addon_name()

    preview_size: IntProperty(
        name="Preview Size",
        default=150,
        soft_max=500,
        min=50,
        description="Size of the preview in pixels"
    )

    live_update_enabled: BoolProperty(
        name="Live Update",
        default=False,
        description="Enable periodic live re-rendering of visible previews"
    )

    live_update_interval: FloatProperty(
        name="Live Update Interval",
        default=0.5,
        min=0.05,
        max=5.0,
        description="Interval in seconds between live preview updates"
    )


    def draw(self, context):

        layout = self.layout
        
        # Main Settings
        box = layout.box()
        box.label(text="Settings", icon="PREFERENCES")

        row = box.row()
        split = row.split(factor=0.5, align=True)
        split.label(text="Node Preview Size (px)")
        split.prop(self, "preview_size", text="")

        # Live update controls
        row = box.row()
        row.prop(self, "live_update_enabled", text="Live Update")
        row.prop(self, "live_update_interval", text="Interval (s)")

        
        #Shortcuts INFO
        info = layout.box()
        info.alignment = "EXPAND"
        info.label(text="Shortcuts:")
        info.label(text="(These can be changed in the Keymap settings)")

        # Add specific shortcut descriptions
        
        info.label(text="Ctrl + P → Open Add-on Menu")
        info.label(text="Ctrl + E → Show/Hide Node Preview")
        info.label(text="Ctrl + O → Select Output Socket for Preview")
        info.label(text="Ctrl + R → Rerender Selected Node Preview")

        # Add a note about customization
        info.label(text="You can customize these shortcuts under 'Preferences → Keymap → Addon Name'.")


class ShaderViewNodeProps(PropertyGroup):
    """
    Property group for storing node preview settings and metadata.
    """

    output_index: IntProperty(
        default=-1,
        name="output socket index",
    )

    # Unique identifier for the node
    uid_: StringProperty(
        default="",
        name="Unique ID",
        description="Unique identifier for the node"
    )

    @property
    def uid(self):
        if self.uid_ == "":
            self.uid_ = str(id(self))
        return self.uid_

    show: BoolProperty(
        default=False,
        name="Show Preview",
        description="Hide or Show the node preview"
    )

    preview_mode: bpy.props.EnumProperty(
        name="Preview Mode",
        description="How to display the node output (channel/vector split)",
        items=[
            ('AUTO', 'Auto', 'Use original output channels'),
            ('R', 'R', 'Red channel / first component'),
            ('G', 'G', 'Green channel / second component'),
            ('B', 'B', 'Blue channel / third component'),
            ('A', 'A', 'Alpha channel / fourth component'),
            ('RGB', 'RGB', 'RGB (use first 3 channels)'),
            ('X', 'X', 'X component (vector)'),
            ('Y', 'Y', 'Y component (vector)'),
            ('Z', 'Z', 'Z component (vector)'),
        ],
        default='AUTO'
    )


    @classmethod
    def register(cls):
        bpy.types.Node.node_preview = bpy.props.PointerProperty(name="Shader View Lite Node Settings", type=cls)

    @classmethod
    def unregister(cls):
        del bpy.types.Node.node_preview


def register():
    register_class(ShaderViewAddonPreferences)
    register_class(ShaderViewNodeProps)

    
def unregister():

    unregister_class(ShaderViewNodeProps)
    unregister_class(ShaderViewAddonPreferences)

   

    
