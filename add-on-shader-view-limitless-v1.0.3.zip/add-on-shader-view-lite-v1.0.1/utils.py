
import bpy
import os
import re

from . import globals


NODES_TO_SKIP = {
    "NodeReroute",
    "ShaderNodeHoldout",
    "NodeGroupInput",
    "NodeGroupOutput",
    "ShaderNodeValue",
    "ShaderNodeRGB",
    "ShaderNodeOutputMaterial"
}

ATTR_TO_SKIP = {
    "color",  
    "dimensions",  
    "width",  
    "width_hidden",
    "height",
    "hide",
    "label",
    "location",
    "name",
    "select",
    "show_options",  # Display options in the UI
    "show_preview",  # Display preview in the UI
    "show_texture",  # Display texture in the UI
    "type",
    "use_custom_color",
    "image",  # skipped as they are processed separately
    "node_tree",  # skipped as they are processed separately
    "inputs",  # skipped as they are processed separately
    "internal_links",  # Internal links within the node tree
    "outputs",  # skipped as they are processed separately
    "parent",  # Parent node reference
    "rna_type",  # Metadata about the RNA type
    "bytecode",  # OSL script node-specific attribute
    "bytecode_hash",  # OSL script node-specific hash
    "node_preview",  # Custom property created by this addon
}

def get_addon_prefs(context):
    addon_name = __package__ if __package__ else "ShaderViewLite"
    return context.preferences.addons[addon_name].preferences


def count_active_outputs(node):
    return sum(1 for socket in node.outputs if not socket.is_unavailable and (socket.enabled or socket.is_linked))


def skip_node(node):
    """
    Determine if a node should be skipped based on its type.
    """
    if node.bl_idname in NODES_TO_SKIP:
        return True
    return False

def skip_attr(attr):
    return attr in ATTR_TO_SKIP


def check_node(node):
    if (node and isinstance(node, bpy.types.ShaderNode) and hasattr(node, "node_preview")
        and hasattr(node, "name") and node.name):
        return True
    return False


def get_space():
    """
    Get the active space of the Node Editor in the current window.
    """

    if bpy.context.window:
        for area in bpy.context.window.screen.areas:
            if area.type == 'NODE_EDITOR':
                space = area.spaces.active
                if hasattr(space, 'tree_type') and space.tree_type == 'ShaderNodeTree':
                        return space
                
    for window_manager in bpy.data.window_managers:
        for window in window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'NODE_EDITOR':
                    space = area.spaces.active
                    if hasattr(space, 'tree_type') and space.tree_type == 'ShaderNodeTree':
                        return space
    
    return None

def get_active_tree():
    """
    Get the currently active node tree in the Node Editor.
    """
    space = get_space()
    if space:
        return space.edit_tree
    return None

def get_main_tree():
    """
    Get the main/root node tree from the active space.
    """
    space = get_space()
    if space and hasattr(space, 'node_tree') and space.node_tree is not None:
        return space.node_tree

    return None


def get_identifier(node_name):
    """
    Convert a node name into a valid identifier.
    Replaces invalid characters with underscores and ensures
    the identifier starts with a letter or an underscore.
    """
    # Replace invalid characters with underscores
    valid_identifier = re.sub(r'\W|^(?=\d)', '_', node_name)
    
    # Ensure the identifier does not start with a digit
    if valid_identifier[0].isdigit():
        valid_identifier = f"a{valid_identifier}"
    
    return valid_identifier


def skip_node_reroute(node, from_socket = None):
    """
    Skip all connected reroute nodes and find the and return the final
    (non-reroute node, socket) that actually produces the data.
    """
    # If it's NOT a reroute, we're done:
    if node.bl_idname != "NodeReroute":
        return node, from_socket

    # If it IS a reroute node, we find the single input link
    node_tree = node.id_data
    links_in = get_tree_links_in(node_tree)
    
    if not node.inputs:
        return (None, None)

    reroute_input_socket = node.inputs[0]  # Reroute typically has exactly 1 input

    # Get the link that feeds into that reroute input
    if reroute_input_socket not in links_in:
        return (None, None)

    link = links_in[reroute_input_socket]
    if not link or not link.from_node:
        return (None, None)

    # This is the next node/socket in the chain
    next_node = link.from_node
    next_socket = link.from_socket  # The 'from_socket' that feeds the Reroute

    # Recurse if the next node is also a Reroute
    return skip_node_reroute(next_node, next_socket)


def find_socket_index(socket_list, socket_to_find):
    """
    Find the index of a specific socket in a list of sockets.
    """
    for index, socket in enumerate(socket_list):
        if socket == socket_to_find:
            return index
    
    return None


def force_redraw():
    for window_manager in bpy.data.window_managers:
        for window in window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'NODE_EDITOR':
                    for region in area.regions:
                        if region.type == 'WINDOW':  # Main content region of the Node Editor
                            region.tag_redraw()


def get_tree_uid(node_tree):

    return globals.object_material + "___" + get_identifier(node_tree.name_full)


def get_node_uid(node):

    if not node or not node.id_data or not node.name or not hasattr(node, "node_preview"):
        print(f"{node} Node has been removed from memory.")
        return None
    
    try:
        return node.node_preview.uid + "___" + get_tree_uid(node.id_data) + "_" + get_identifier(node.name)
    except ReferenceError:
        print(f"{node} Node has been removed from memory.")
        return None
    

def safe_remove_handler(handler, handler_type):
    """
    Safely remove a handler from the handler list, only if it's present.
    """

    handler_list = getattr(bpy.app.handlers, handler_type, None)

    if handler_list is None:
        return

    if handler in handler_list:
        handler_list.remove(handler)


def get_addon_name():
    return __package__ if __package__ else "ShaderViewLite"


def get_tree_links_in(node_tree):

    in_links = {}
    for link in node_tree.links:
        in_links[link.to_socket] = link
    
    return in_links

def get_absolute_node_position(node):
    """
    Get the global position of a node, accounting for frames and transformations.
    """
    node_x, node_y = node.location

    # Check if the node is inside a frame and account for frame offset
    parent = node.parent
    while parent:
        node_x += parent.location.x
        node_y += parent.location.y
        parent = parent.parent

    return node_x, node_y


def process_path(filepath):
    """Process and normalize a file path for Blender and OS compatibility."""

    filepath = os.path.expanduser(filepath) # Expand user directory 
    filepath = bpy.path.abspath(filepath)  # Convert relative Blender paths to absolute
    filepath = os.path.normpath(filepath)  # Normalize OS-specific path separators
    filepath = filepath.replace("\\", "/")
    return filepath


def calculate_preview_params(node, view2d, zoom):
    """
    Calculate common drawing parameters for a node preview.
    """

    ui_scale = bpy.context.preferences.system.ui_scale

    addon_prefs = get_addon_prefs(bpy.context)
    size = addon_prefs.preview_size
    
    # Get global position of the node
    node_x, node_y = get_absolute_node_position(node)
    node_x *= ui_scale
    node_y *= ui_scale

    node_width = node.dimensions[0] 
    node_height = node.dimensions[1]


    node_min_x, node_min_y = view2d.view_to_region(node_x, node_y, clip=False)
    node_max_x, node_max_y = view2d.view_to_region(
        node_x + node_width, node_y - node_height, clip=False
    )

    extra_offset_y = 0.0

    if node.hide:
        extra_offset_y = (node_min_y - node_max_y) * 0.5
        extra_offset_y -= 6.0 * ui_scale * zoom

    scaled_size = size * ui_scale  # Scaled preview size
    node_center_x = node_x + (node_width / 2)

    # Compute preview position (adjusted for UI scaling)
    preview_min_x, preview_min_y = view2d.view_to_region(node_center_x - scaled_size * 0.5, node_y, clip=False)
    preview_max_x, preview_max_y = view2d.view_to_region(
        node_center_x + scaled_size * 0.5, node_y + scaled_size, clip=False
    )

    scaled_offset_y = 10 * ui_scale * zoom
    preview_min_y += scaled_offset_y + extra_offset_y
    preview_max_y += scaled_offset_y + extra_offset_y

    return {
        "bottom_left": (preview_min_x, preview_min_y),
        "bottom_right": (preview_max_x, preview_min_y),
        "top_right": (preview_max_x, preview_max_y),
        "top_left": (preview_min_x, preview_max_y)
    }


def get_context_region():

    region = bpy.context.region
    if not region:
        return None
    
    view2d = region.view2d
    if not view2d:
        return None
    
    space = bpy.context.space_data
    if not space:
        return None
    
    if (
        not hasattr(space, 'node_tree') 
        or not space.node_tree 
        or space.node_tree.bl_idname != 'ShaderNodeTree' 
        or space.type != 'NODE_EDITOR' 
        or space.node_tree.library is not None
        or space.tree_type != 'ShaderNodeTree'
        ):
        return None

    return region



def get_eevee_engine():
    available_engines = bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items.keys()
    for engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
        if engine in available_engines:
            return engine
    return 'CYCLES'


def find_first_available_output(node):

    if node.type == 'SCRIPT' and isinstance(node, bpy.types.ShaderNodeScript):
        return None

    # First, try to find the first linked output
    linked_index = next((i for i, socket in enumerate(node.outputs) if not socket.is_unavailable and socket.is_linked), None)
    
    if linked_index is not None:
        return linked_index
    
    # If no linked output is found, find the first enabled output
    enabled_index = next((i for i, socket in enumerate(node.outputs) if not socket.is_unavailable and socket.enabled), None)
    
    if enabled_index is not None:
        return enabled_index
    
    return None


def apply_output_index(node, index):
    node.node_preview.output_index = index
    return None


def update_output_index(node):

    if count_active_outputs(node) == 0:
        return
    
    if node.node_preview.output_index < 0:
        output_index = find_first_available_output(node)
        if output_index is not None:
            bpy.app.timers.register(lambda n=node, i=output_index: apply_output_index(n,i))
        return

    avaliable_sokets = [socket for socket in node.outputs if not socket.is_unavailable and (socket.enabled or socket.is_linked)]
    selected_socket = node.outputs[node.node_preview.output_index] if node.node_preview.output_index is not None else None

    if selected_socket not in avaliable_sokets:
        output_index = find_first_available_output(node)
        bpy.app.timers.register(lambda n=node, i=output_index: apply_output_index(n,i))
            

def is_renderable(node):

    node_id = get_node_uid(node)

    if node_id is None:
        return False

    if (skip_node(node)
        or not check_node(node)
        or not node.node_preview.show):
        return False
    
    if count_active_outputs(node) == 0:
        return False
    
    return True


def get_zoom(region):

    v2d = region.view2d
    x1, y1 = v2d.region_to_view(0, 0)
    x2, y2 = v2d.region_to_view(region.width, region.height)
    v2d_width = x2 - x1
    scale_x = region.width / v2d_width
    return scale_x