
import gpu

def numpy_array_to_gpu_texture(arr):

    height, width, channels = arr.shape

    if channels == 4:
        format_str = "RGBA16F"
    elif channels == 3:
        format_str = "RGB16F"
    elif channels == 1:
        format_str = "R32F"
    else:
        print(f"ERROR: Unsupported number of channels: {channels}")
        return None

    buffer = gpu.types.Buffer("FLOAT", height * width * channels, arr.flatten())
    return gpu.types.GPUTexture((width, height), format=format_str, data=buffer)



def preview_shader():
    """
    Create a GPU shader for rendering textures with extra logics.
    """
    vert_out = gpu.types.GPUStageInterfaceInfo("my_interface")
    vert_out.smooth('VEC2', "uvInterp")
    shader_info = gpu.types.GPUShaderCreateInfo()

    shader_info.push_constant('MAT4', "ModelViewProjectionMatrix")
    shader_info.sampler(0, 'FLOAT_2D', "image")

    shader_info.vertex_in(0, 'VEC2', "pos")
    shader_info.vertex_in(1, 'VEC2', "uv")
    shader_info.vertex_out(vert_out)

    shader_info.fragment_out(0, 'VEC4', "FragColor")

    # Vertex Shader
    shader_info.vertex_source('''
    void main()
    {   
        gl_Position = ModelViewProjectionMatrix * vec4(pos.xy, 0.0f, 1.0f);
        gl_Position.z = 1.0; // ensure the quad is rendered within Shader Editor
        uvInterp = uv;

    }''')

    # Fragment Shader
    shader_info.fragment_source('''
    void main()
    {           
        vec4 base_color = texture(image, uvInterp);
        const float gamma_correct = 2.2;
        base_color.rgb = pow(base_color.rgb, vec3(gamma_correct));
        FragColor = base_color;

    }''')

    return gpu.shader.create_from_info(shader_info)