
import bpy
import traceback
import time
from bpy.app.handlers import persistent
from concurrent.futures import ThreadPoolExecutor

from . import globals
from .render_script import get_node_preview_script, get_settings_script
from .utils import (
    get_main_tree, get_node_uid, get_space, get_tree_uid, 
    safe_remove_handler, get_active_tree,
    force_redraw, update_output_index, 
    get_addon_prefs,
)

update_handler = None
render_executor = None
last_active_tree = None

deferred_timer_handle = None
last_graph_update = 0.0


class Task:
    def __init__(self, func, *args, **kwargs):
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def execute(self):

        try:
            return self.func(*self.args, **self.kwargs)  # Run function
        except Exception as e:
            error_trace = traceback.format_exc()  # Get full error trace
            print(f"ERROR: Task {self.func.__name__} failed!\n{error_trace}")
            return None  # Ensure it doesn't crash
    
    def __call__(self):
        return self.execute()


def render_node(node):
    render_executor.submit(Task(render, node))


def check_node_tree_state():
    """
    Update the state of a node tree, including links, shader node data, and dirty flags.
    """
    
    if not (globals.bg_ready.is_set() and globals.tree_ready.is_set()):
        return

    node_tree = get_active_tree()
    if not node_tree:
        return
    
    node_to_render = None
    for node in node_tree.nodes:

        if node.node_preview.show:
            node_to_render = node

        update_output_index(node)
    
    if node_to_render is not None:
        render_node(node_to_render)


@persistent
def scene_graph_update(scene, depsgraph):
    """
    Handler function called whenever there's an update in the dependency graph.
    This function generates script text and hash for each node, compares with stored data,
    and prints the node and attribute that were changed.
    """

    if not (globals.bg_ready.is_set() and globals.tree_ready.is_set()):
        return
        

    for depsgraph_update in reversed(depsgraph.updates):

        updated_id = depsgraph_update.id
       
        if isinstance(updated_id, bpy.types.ShaderNodeTree):

            if not hasattr(updated_id, "name_full") or not updated_id.name_full:
                print(f"[{updated_id}] ShaderNodeTree has been removed", level="Warning")
                return

            tree_id = get_tree_uid(updated_id)
            
            if updated_id.name == "Shader Nodetree":

                graph_update()

            elif isinstance(updated_id, bpy.types.NodeTree):
                if tree_id not in globals.tree_layout:
                    setup_tree_layout()
                    return     
    

def graph_update():

    global last_graph_update, deferred_timer_handle
    update_threshold = 0.2
    current_time = time.time()
    elapsed_time = current_time - last_graph_update

    if deferred_timer_handle is not None:
        bpy.app.timers.unregister(deferred_timer_handle)
        deferred_timer_handle = None
    
    if elapsed_time >= update_threshold: # if we are here, enough time has passed 
        last_graph_update = current_time
        check_node_tree_state()
        
    else:
        remaining_time = max(update_threshold - elapsed_time, 0.2)
        deferred_timer_handle = bpy.app.timers.register(deferred_graph_update, first_interval=remaining_time)


def deferred_graph_update():
    """
    This function is called by bpy.app.timers after the delay.
    """
    global last_graph_update
    last_graph_update = time.time()

    check_node_tree_state()
    return None


def setup_active_tree():
    """
    Marks all unprocessed, renderable nodes in the active node tree as dirty to prepare them for rendering.
    """

    node_tree = get_active_tree()
    if node_tree is None:
        print("ERROR: No active tree")
        return None

    if not globals.tree_ready.wait(timeout=0.3):
        bpy.app.timers.register(setup_active_tree)
        return None

    node_to_render = None
    for node in node_tree.nodes:

        if node.node_preview.show:
            node_to_render = node

        update_output_index(node)
    
    if node_to_render is not None:
        render_node(node_to_render)

    force_redraw()

    return None           



def setup_tree_layout():
    """
    Sets up the node tree layout by initializing the main tree and identifying all group nodes.
    """

    globals.tree_ready.clear()

    with globals.tree_lock:
        globals.tree_layout.clear()
    
    def initialize_main_tree(retries=10, delay=0.1):
        """
        Wait for the context to update and retrieve the active node tree.
        Use this during initialization after loading a new blend file.
        """
        for _ in range(retries):
            tree = get_main_tree()
            if tree:
                return tree
            time.sleep(delay)  # Allow time for Blender to update the context
        
        print("Failed to get the main tree after retries.")
        return None
    
    def find_all_groups(node_tree):
        with globals.tree_lock:
            stack = [node_tree]
            while stack:
                current_tree = stack.pop()
                for node in current_tree.nodes:
                    if isinstance(node, bpy.types.ShaderNodeGroup) and node.node_tree:
                        group_tree_id = get_tree_uid(node.node_tree)
                        globals.tree_layout[group_tree_id] = node
                        stack.append(node.node_tree)
        
    base_tree = initialize_main_tree()

    if base_tree:

        find_all_groups(base_tree)
        globals.tree_ready.set()

    else:
        print("[setup_tree_layout] base tree not found.")    

    return None


@persistent
def update_callback():
    """
    Draw callback function that iterates over all shader nodes in the node tree,
    checks if they have an image path and are enabled, then draws the preview.
    """

    global last_active_tree

    space = get_space()
    if not space:
        return
    
    if not globals.bg_ready.is_set():
        return
            
    obj = bpy.context.active_object
    if obj and obj.active_material:

        active_tree = get_active_tree()
        object_material = str(id(obj)) + '_' + str(id(obj.active_material))

        if object_material != globals.object_material and active_tree:
            globals.object_material = object_material
            setup_tree_layout()
        
        if active_tree and active_tree != last_active_tree:
            last_active_tree = active_tree
            bpy.app.timers.register(setup_active_tree)
               

def render(node):

    node_id = get_node_uid(node)
    node_tree_id = get_tree_uid(node.id_data)

    node_script = get_node_preview_script(node)

    if isinstance(node_script, list):
        node_script = "\n".join(node_script)
    
    if 'ERROR_MSG' in node_script:        
        globals.error_msg = "Error"
        if "ERROR_IMG" in node_script:
            globals.error_msg = "No image assigned to ImageTexture Node"
        elif "ERROR_NODE" in node_script:
            globals.error_msg = "Attribute Node is not supported"
        elif "ERROR_IMG_SOURCE" in node_script:
            globals.error_msg = "This IMG source is not supported, switch to Full version"
        elif "ERROR_CYCLES" in node_script:
            globals.error_msg = "CYCLES is not supported, switch to Full version"
        elif "ERROR_SCRIPT" in node_script:
            globals.error_msg = "Script Node is not supported, switch to Full version"
            
        return

    settings_script = get_settings_script()

    if isinstance(settings_script, list):
        settings_script = "\n".join(settings_script)

    json_args = {
            "status": "DRAW_PREVIEW",
            "script": settings_script + node_script,
            "node_id": node_id,
            "tree_id": node_tree_id
        }

    globals.task_queue.put(json_args)



def reset_executer():

    global render_executor

    if render_executor:
        render_executor.shutdown(wait=False)
        render_executor = None

    render_executor = ThreadPoolExecutor(max_workers=1)


@persistent
def update_nodes():

    if not (globals.bg_ready.is_set() and globals.tree_ready.is_set()):
        return 1
    
    node_tree = get_active_tree()
    if not node_tree:
        return 1
    
    if not globals.result:
        return 1

    current_time = time.time()
    for node in node_tree.nodes:
        node_id = get_node_uid(node)
        node_result = globals.result.get(node_id)
        if (node_result and
            node.node_preview.show and
            node_result.get('arr') is None and
            node_result.get('timestamp') and
            current_time - node_result['timestamp'] > 1.0):
            # update timestamp and re-render this node
            node_result['timestamp'] = current_time
            render_node(node)
            break
    
    return 1


@persistent
def check_timers_timer():
    """Checks if all timers are registered regularly. Prevents possible bugs from stopping the addon."""
    if not bpy.app.timers.is_registered(update_nodes_timer):
        bpy.app.timers.register(update_nodes_timer, persistent=True, first_interval=1)
    return 5



@persistent
def update_nodes_timer():
    update_nodes()
    return 1
    

def unregister_timers():
    """Unregister all timers at the very start of unregistration.
    This prevents the timers being called before the unregistration finishes.
    """
    if bpy.app.timers.is_registered(check_timers_timer):
        bpy.app.timers.unregister(check_timers_timer)
    if bpy.app.timers.is_registered(update_nodes_timer):
        bpy.app.timers.unregister(update_nodes_timer)
    # Unregister live update timer if present
    try:
        if bpy.app.timers.is_registered(live_update_timer):
            bpy.app.timers.unregister(live_update_timer)
    except NameError:
        pass


def live_update_timer():
    """
    Periodically re-render visible previews when live update is enabled in preferences.
    Returns the interval (seconds) for the next call.
    """
    try:
        prefs = get_addon_prefs(bpy.context)
    except Exception:
        # Fallback interval
        return 1.0

    interval = getattr(prefs, 'live_update_interval', 0.5)
    if not getattr(prefs, 'live_update_enabled', False):
        return interval

    if not (globals.bg_ready.is_set() and globals.tree_ready.is_set()):
        return interval

    node_tree = get_active_tree()
    if not node_tree:
        return interval

    now = time.time()
    for node in node_tree.nodes:
        try:
            if not node.node_preview.show:
                continue
        except Exception:
            continue

        node_id = get_node_uid(node)
        node_result = globals.result.get(node_id)
        pending = bool(node_result and node_result.get('arr') is None)
        last_ts = node_result.get('timestamp') if node_result else 0

        # If no pending render or last render is older than interval, schedule a render
        if (not pending) or (now - last_ts > interval):
            with globals.result_lock:
                globals.result[node_id] = {
                    'node_id': node_id,
                    'arr': None,
                    'timestamp': now
                }
            render_node(node)

    return interval



def register():

    reset_executer()

    global update_handler
    if update_handler is None:
        update_handler = bpy.types.SpaceNodeEditor.draw_handler_add(update_callback, (), 'WINDOW', 'POST_PIXEL')
    # Register live-update timer (will early-return if disabled)
    try:
        prefs = get_addon_prefs(bpy.context)
        first = getattr(prefs, 'live_update_interval', 0.5)
    except Exception:
        first = 1.0

    try:
        bpy.app.timers.register(live_update_timer, persistent=True, first_interval=first)
    except Exception:
        pass

    safe_remove_handler(scene_graph_update, 'depsgraph_update_post')
    bpy.app.handlers.depsgraph_update_post.append(scene_graph_update)

    bpy.app.timers.register(check_timers_timer, persistent=True)


def unregister():
    
    global update_handler, render_executor, last_graph_update, last_active_tree, deferred_timer_handle

    unregister_timers()

    if render_executor:
        render_executor.shutdown(wait=False)
        render_executor = None

    safe_remove_handler(scene_graph_update, 'depsgraph_update_post')

    if update_handler is not None:
        bpy.types.SpaceNodeEditor.draw_handler_remove(update_handler, 'WINDOW')
        update_handler = None
    
    last_graph_update = 0.0
    last_active_tree = None
    deferred_timer_handle = None