
import gpu
import bpy
import blf
import numpy as np
from gpu_extras.batch import batch_for_shader

from . import globals
from .display_utils import numpy_array_to_gpu_texture, preview_shader
from .utils import calculate_preview_params, get_node_uid, get_addon_prefs


def draw_preview(node, view2d, zoom):
    """
    Draw the image preview above the shader node in the node editor.
    """
       
    preview_params = calculate_preview_params(node, view2d, zoom)
    
    if globals.shader is None:
        globals.shader = preview_shader()

    shader = globals.shader

    with globals.result_lock, globals.texture_lock:
        node_id = get_node_uid(node)
        preview_texture = globals.cashed_textures.get(node_id)
        if preview_texture is None:
            node_result = globals.result.get(node_id)
            numpy_arr = node_result.get('arr') if node_result else None
            if isinstance(numpy_arr, np.ndarray) and numpy_arr.size > 0:
                    # Apply per-node preview mode (channel/vector splitting)
                    mode = getattr(node.node_preview, 'preview_mode', 'AUTO') if hasattr(node, 'node_preview') else 'AUTO'
                    arr_for_tex = None

                    try:
                        h, w, ch = numpy_arr.shape
                    except Exception:
                        arr_for_tex = numpy_arr

                    if arr_for_tex is None:
                        if mode == 'AUTO' or ch in (3, 4) and mode == 'RGB':
                            arr_for_tex = numpy_arr
                        elif mode == 'RGB':
                            # try to build RGB from first channels
                            if ch >= 3:
                                arr_for_tex = numpy_arr[:, :, :3]
                            elif ch == 1:
                                arr_for_tex = np.repeat(numpy_arr, 3, axis=2)
                            else:
                                arr_for_tex = np.zeros((h, w, 3), dtype=np.float32)
                        elif mode in ('R', 'G', 'B', 'A', 'X', 'Y', 'Z'):
                            idx_map = {'R':0, 'G':1, 'B':2, 'A':3, 'X':0, 'Y':1, 'Z':2}
                            idx = idx_map.get(mode, 0)
                            if ch > idx:
                                channel = numpy_arr[:, :, idx]
                            else:
                                channel = np.zeros((h, w), dtype=numpy_arr.dtype)
                            arr_for_tex = channel.reshape((h, w, 1))
                        else:
                            arr_for_tex = numpy_arr

                    # Ensure float32
                    if arr_for_tex is not None and arr_for_tex.dtype != np.float32:
                        arr_for_tex = arr_for_tex.astype(np.float32)

                    tex = numpy_array_to_gpu_texture(arr_for_tex)
                    globals.cashed_textures[node_id] = tex
                    preview_texture = tex


    if preview_texture is None:
        print(f"Error: Texture is missing for node {get_node_uid(node)}")
        return
    
    gpu.state.blend_set("ALPHA")
    
    shader.bind()

    # Compute preview positions once.
    pos = [
        preview_params["bottom_left"],
        preview_params["bottom_right"],
        preview_params["top_right"],
        preview_params["top_left"]
    ]
    uv_coords = [
        (0.0, 0.0),  # Bottom-left
        (1.0, 0.0),  # Bottom-right
        (1.0, 1.0),  # Top-right
        (0.0, 1.0)   # Top-left
    ]
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": pos, "uv": uv_coords})
    
    try:
        shader.uniform_sampler("image", preview_texture)        
        batch.draw(shader)

    except Exception as e:
        print(f"Cached texture is invalid or corrupted... error: {e}", level="ERROR")
        with globals.texture_lock:
            globals.cashed_textures.pop(get_node_uid(node), None)
    
    gpu.state.blend_set("NONE")


def draw_node_placeholder(preview_params, texture):
    """
    Draw a placeholder above the shader node in the node editor.
    """

    if texture is None:
        print("draw_node_placeholder: texture is not ready")
        return

    if globals.shader is None:
        globals.shader = preview_shader()

    shader = globals.shader
    
    gpu.state.blend_set("ALPHA")
   
    shader.bind()
    # Compute preview positions once.
    pos = [
        preview_params["bottom_left"],
        preview_params["bottom_right"],
        preview_params["top_right"],
        preview_params["top_left"]
    ]
    uv_coords = [
        (0.0, 0.0),  # Bottom-left
        (1.0, 0.0),  # Bottom-right
        (1.0, 1.0),  # Top-right
        (0.0, 1.0)   # Top-left
    ]
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": pos, "uv": uv_coords})

    try:
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
    except Exception as e:
        print(f"draw node_placeholder error: {e}", level="ERROR")
        return


def draw_setup(text):
    
    # Use consistent coordinates to avoid rounding errors
    ui_scale = bpy.context.preferences.system.ui_scale
    text_x = 10 * ui_scale  # Adjust horizontal margin
    text_y = 20 * ui_scale  # Adjust vertical margin

    # Enable blending for transparency
    gpu.state.blend_set("ALPHA")

    # Set font properties
    font_id = 0  # Default font ID
    font_size = 12
    rounded_size = int(font_size * ui_scale)

    if bpy.app.version < (4, 0, 0):
        blf.size(font_id, rounded_size, 72)
    else:
        blf.size(font_id, rounded_size)

    # Draw the text at the specified position
    blf.position(font_id, text_x, text_y, 0)
    blf.color(font_id, 0.0, 1.0, 0.0, 1.0)  # Green text
    blf.draw(font_id, text)
    gpu.state.blend_set("NONE")


def draw_text(text, font_size, text_pos, scale, color=(1.0, 1.0, 1.0, 1.0)):

    gpu.state.blend_set("ALPHA")
    # Draw the text in the middle
    font_id = 0  # Default font ID
    rounded_size = int(font_size * scale)

    if bpy.app.version < (4, 0, 0):
        blf.size(font_id, rounded_size, 72)
    else:
        blf.size(font_id, rounded_size)
    text_x, text_y = text_pos
    width, height = blf.dimensions(font_id, text)
    text_x -= width * 0.5
    text_y -= rounded_size * 0.5
    # Draw the text at the specified position
    blf.position(font_id, text_x, text_y, 0)
    blf.color(font_id, *color)
    blf.draw(font_id, text)
    gpu.state.blend_set("NONE")
    


def draw_empty(node, texture, text, view2d, zoom):
   
    addon_prefs = get_addon_prefs(bpy.context)
    # Get drawing parameters
    preview_params = calculate_preview_params(node, view2d, zoom)

    draw_node_placeholder(preview_params, texture)

    font_size = 10
    preview_center = (
        0.5 * (preview_params["bottom_left"][0] + preview_params["top_right"][0]),
        0.5 * (preview_params["bottom_left"][1] + preview_params["top_right"][1]),
    )

    ui_scale = bpy.context.preferences.system.ui_scale
    draw_text(text, font_size, preview_center, ui_scale * zoom)