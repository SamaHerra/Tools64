
import bpy
from . import globals
from .utils import (
    get_eevee_engine, get_node_uid, find_socket_index, get_tree_links_in, 
    skip_node_reroute, get_node_uid, get_tree_uid
)
from .node_script import get_node_script, io_node_sockets_to_script, node_links_to_script, group_sockets_to_script, is_script_node


def all_linked_nodes_to_script(start_node, script_node, script_links, tree_data, upward=False, processed_nodes = None):
    """
    Recursively processes all linked nodes, appending their script representations
    and link connections to the provided script_node and script_links lists.

    Args:
        start_node: The starting node to begin processing.
        script_node: A list to collect script lines for node creation.
        script_links: A list to collect script lines for link creation.
        tree_data: 
        upward: Whether to traverse upward for node groups.
        processed_nodes: A dictionary of already processed nodes to avoid repetition.

    """

    if processed_nodes is None:
        processed_nodes = {}

    node_id = get_node_uid(start_node)
    if node_id is None:
        return
    
    if node_id in processed_nodes:
        return

    if not isinstance(start_node, bpy.types.ShaderNodeGroup):

        node_script, links_script = get_node_script(start_node)
        script_node.extend(node_script)
        script_links.extend(links_script)

    processed_nodes[node_id] = node_id

    node_tree = start_node.id_data
    node_tree_id = get_tree_uid(node_tree)

    in_links = get_tree_links_in(node_tree)

    for input_socket in start_node.inputs:
        if input_socket in in_links:

            if input_socket.is_unavailable or not input_socket.enabled:
                continue

            link = in_links[input_socket]

            if not link or not link.from_node:
                continue

            from_node, _ = skip_node_reroute(link.from_node)

            if from_node:

                from_node_id = get_node_uid(from_node)
                if from_node_id is None:
                    continue

                if from_node_id in processed_nodes:
                    continue

                if isinstance(from_node, bpy.types.NodeGroupInput):

                    processed_nodes[from_node_id] = from_node_id
                    
                    if node_tree_id in tree_data:
                        group_node = tree_data[node_tree_id]
                        io_node_sockets_to_script(group_node, script_node)
                        node_links_to_script(group_node, script_links)
                    
                        if upward:
                            all_linked_nodes_to_script(group_node, script_node, script_links, tree_data, True, processed_nodes)                        
                    else:
                        continue

                elif isinstance(from_node, bpy.types.ShaderNodeGroup):
                    
                    node_script, links_script = get_node_script(from_node)
                    script_node.extend(node_script)
                    group_sockets_to_script(from_node, script_node)
                    group_node_to_script(from_node, script_node, script_links, tree_data)
                    all_linked_nodes_to_script(from_node, script_node, script_links, tree_data, upward, processed_nodes)
                else:
                    all_linked_nodes_to_script(from_node, script_node, script_links, tree_data, upward, processed_nodes)


def group_node_to_script(group_node, script_node, script_links, tree_data):
    """
    Handles the script generation for group nodes, upward is alwasy False.
    """
    
    group_tree_id = get_tree_uid(group_node.node_tree)

    in_links = get_tree_links_in(group_node.node_tree)
    output_node = next((node for node in group_node.node_tree.nodes if isinstance(node, bpy.types.NodeGroupOutput)), None)
    
    if not output_node:
        return
    
    output_node_id = get_node_uid(output_node)
    if output_node_id is None:
        return

    # Process each input socket of the output node
    processed_nodes = {}

    for input_socket in output_node.inputs:
        if input_socket in in_links:
            
            link = in_links[input_socket]

            if not link.from_node:
                continue

            from_node, from_socket = skip_node_reroute(link.from_node, link.from_socket)

            if from_node and from_socket:

                if is_script_node(from_node):
                    script_node.append("# ERROR_MSG ERROR_SCRIPT")
                    continue

                from_node_id = get_node_uid(from_node)
                if from_node_id is None:
                    continue

                output_index = find_socket_index(from_node.outputs, from_socket)
                input_index = find_socket_index(output_node.inputs, input_socket)

                if output_index is None or input_index is None:
                    continue
                
                script_links.append(f"{short_name(group_tree_id)}.links.new({short_name(from_node_id)}.outputs[{output_index}], {short_name(output_node_id)}.inputs[{input_index}])")
 
                if isinstance(from_node, bpy.types.ShaderNodeGroup):
   
                    node_script, links_script = get_node_script(from_node)

                    script_node.extend(node_script)
                    group_sockets_to_script(from_node, script_node)
                    group_node_to_script(from_node, script_node, script_links, tree_data)

                # Recursively process all linked nodes in this group
                all_linked_nodes_to_script(from_node, script_node, script_links, tree_data, False, processed_nodes)


def short_name(name):
    return name.split("___")[-1]


def get_node_preview_script(node):
    """
    Generates the preview script for a given node. If the script is cached and up-to-date,
    it uses the cached version; otherwise, it generates a new one and updates the cache.
    """
    script_node, script_links, node_output_links, setup_script = [], [], [], []

    node_id = get_node_uid(node)
    if node_id is None:
        return []
    
    index = node.node_preview.output_index
    if index < 0:
        return []

    if is_script_node(node):
        return ["# ERROR_MSG ERROR_SCRIPT"]

    socket_type = node.outputs[index].bl_idname
 
    node_tree = node.id_data
    node_tree_id = get_tree_uid(node_tree)

    tree_data = globals.tree_layout.copy()

    pending_trees, processed_trees = [node_tree_id], []
    # Process nodes trees (all group nodes) in reverse order
    while pending_trees:

        current_tree_id = pending_trees.pop(0)
        processed_trees.append(current_tree_id)
     
        if current_tree_id in tree_data:

            if node_id is None:
                return

            group_node = tree_data[current_tree_id]
            pending_trees.append(get_tree_uid(group_node.id_data))

            node_name = short_name(node_id)
            tree_name = short_name(current_tree_id)

            #small hack to connect any node inside the group with output node
            if bpy.app.version >= (4, 0, 0):
                node_output_links.append(f"{tree_name}.interface.new_socket('{node_name}', "
                                        f"in_out='OUTPUT', "
                                        f"socket_type={repr(socket_type)})")
            else:
                node_output_links.append(f"{tree_name}.outputs.new({repr(socket_type)}, '{node_name}')")
        
            output_node = next((node for node in group_node.node_tree.nodes if isinstance(node, bpy.types.NodeGroupOutput)), None)
            output_node_id = get_node_uid(output_node)
            if output_node and output_node_id is not None:
                node_output_links.append(f"{tree_name}.links.new({node_name}.outputs[{index}],{short_name(output_node_id)}.inputs['{node_name}'])")
            
            index = repr(short_name(node_id))
            node_id = get_node_uid(group_node)

        else:

            node_name = short_name(node_id)
            tree_name = short_name(current_tree_id)
            

            if socket_type == 'NodeSocketShader':
                node_output_links.append(f"{tree_name}.links.new({node_name}.outputs[{index}], output_node.inputs['Surface'])")
            else:
                node_output_links.append(f"{tree_name}.links.new({node_name}.outputs[{index}], emission_node.inputs['Color'])")
                node_output_links.append(f"{tree_name}.links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])")

            node_output_links.append("bpy.context.view_layer.update()")

    while processed_trees:

        current_tree_id = processed_trees.pop()

        if current_tree_id in tree_data:
            group_node = tree_data[current_tree_id]
            group_node_id = get_node_uid(group_node)
            if group_node_id is None:
                return

            node_script, links_script = get_node_script(group_node)
            setup_script.extend(node_script)
            group_sockets_to_script(group_node, setup_script)    

    
    node_id = get_node_uid(node)

    if isinstance(node, bpy.types.ShaderNodeGroup):
        node_script, links_script = get_node_script(node)
        script_node.extend(node_script)
        group_sockets_to_script(node, script_node)
        group_node_to_script(node, script_node, script_links, tree_data)

    processed_nodes = {}
    all_linked_nodes_to_script(node, script_node, script_links, tree_data, True, processed_nodes)


    return setup_script + script_node + script_links + node_output_links


def get_settings_script():
    """
    Generate a Python script to be executed in Blender background mode
    to set up a material with the selected node to render a thumbnail.
    """
    
    def setup_scene(engine):
        """Setup the scene and render settings."""


        return f"""
import bpy
from contextlib import suppress

scene = bpy.context.scene
render_settings = bpy.context.scene.render
render_settings.engine = '{engine}'
render_settings.use_border = False
render_settings.use_crop_to_border = False
scene.eevee.taa_samples = 2
scene.eevee.taa_render_samples = 2

with suppress(Exception):
    scene.eevee.use_shadows = False
    scene.eevee.use_bloom = False
    scene.eevee.use_gtao = False        
    scene.eevee.use_ssr = False         
    scene.eevee.use_motion_blur = False
   
if bpy.app.version < (3, 0, 0):
    scene.render.tile_x = 32
    scene.render.tile_y = 32

# Remove all node groups
for node_group in bpy.data.node_groups:
    bpy.data.node_groups.remove(node_group, do_unlink=True)

# Remove all images
for image in bpy.data.images:
    bpy.data.images.remove(image, do_unlink=True)

# Remove all materials
for mat in bpy.data.materials:
    bpy.data.materials.remove(mat, do_unlink=True)

# Remove all scripts
for text in bpy.data.texts:
    bpy.data.texts.remove(text, do_unlink=True)

bpy.context.view_layer.update()

base_material = bpy.data.materials.new(name="Material")
base_material.use_nodes = True

with suppress(Exception):
    base_material.use_fake_user = True

    base_material.alpha_threshold = 0.0
    base_material.use_transparent_shadow = False

    base_material.surface_render_method = 'BLENDED'
    base_material.blend_method = 'OPAQUE' #deprecated
    
    base_material.use_backface_culling = True
    base_material.alpha_threshold = 0.0

    base_material.use_tranparency_overlap = True
    base_material.show_transparent_back = True #deprecated
    
    base_material.use_raytrace_refraction = False
    base_material.use_screen_refraction = False #deprecated
    
    base_material.refraction_depth = 0.0 #deprecated
    base_material.use_sss_translucency = False #deprecated

    
# Clear existing nodes
base_material.node_tree.nodes.clear()

Shader_Nodetree = base_material.node_tree

# Add essential nodes
output_node = base_material.node_tree.nodes.new(type="ShaderNodeOutputMaterial")
emission_node = base_material.node_tree.nodes.new(type="ShaderNodeEmission")

plane = bpy.data.objects.get("Plane")
plane.data.materials.clear()
plane.data.materials.append(base_material)

bpy.context.view_layer.update()

"""

    def setup_colors():
        
        chosen_colorspace = bpy.context.scene.sequencer_colorspace_settings.name
        if chosen_colorspace not in ["sRGB", "Raw", "Non-Color"]:
            chosen_colorspace = 'sRGB'
        
        return f"""
# Color Management settings
with suppress(Exception):
    scene.view_settings.view_transform = '{bpy.context.scene.view_settings.view_transform}'
    scene.view_settings.look = '{bpy.context.scene.view_settings.look}'
    scene.view_settings.exposure = {bpy.context.scene.view_settings.exposure}
    scene.view_settings.gamma = {bpy.context.scene.view_settings.gamma}
    scene.display_settings.display_device = '{bpy.context.scene.display_settings.display_device}'
    scene.sequencer_colorspace_settings.name = '{chosen_colorspace}'

""" 
        
    render_engine = get_eevee_engine()
    if render_engine  == 'CYCLES':
        return "# ERROR_MSG ERROR_CYCLES"

    scene_script = setup_scene(render_engine)
    colorspace_script = setup_colors()
    
    return scene_script + colorspace_script